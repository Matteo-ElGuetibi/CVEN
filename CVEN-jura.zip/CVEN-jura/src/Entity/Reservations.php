<?php

namespace App\Entity;

use App\Repository\ReservationsRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ReservationsRepository::class)]
class Reservations
{
    public function __toString(){
        return $this->$Categorie;
    }

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'date')]
    private $Date_Arrivee;

    #[ORM\Column(type: 'date')]
    private $Date_Depart;

    #[ORM\Column(type: 'integer')]
    private $Nombre_Client;

    #[ORM\Column(type: 'boolean')]
    private $Restauration;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $Menage;

    #[ORM\Column(type: 'integer')]
    private $Prix;

    #[ORM\Column(type: 'integer')]
    private $Hebergement;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $Pension_Complete;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $DemiPension;


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateArrivee(): ?\DateTimeInterface
    {
        return $this->Date_Arrivee;
    }

    public function setDateArrivee(\DateTimeInterface $Date_Arrivee): self
    {
        $this->Date_Arrivee = $Date_Arrivee;

        return $this;
    }

    public function getDateDepart(): ?\DateTimeInterface
    {
        return $this->Date_Depart;
    }

    public function setDateDepart(\DateTimeInterface $Date_Depart): self
    {
        $this->Date_Depart = $Date_Depart;

        return $this;
    }

    public function getNombreClient(): ?string
    {
        return $this->Nombre_Client;
    }

    public function setNombreClient(string $Nombre_Client): self
    {
        $this->Nombre_Client = $Nombre_Client;

        return $this;
    }

    public function getRestauration(): ?bool
    {
        return $this->Restauration;
    }

    public function setRestauration(bool $Restauration): self
    {
        $this->Restauration = $Restauration;

        return $this;
    }

    public function getMenage(): ?bool
    {
        return $this->Menage;
    }

    public function setMenage(?bool $Menage): self
    {
        $this->Menage = $Menage;

        return $this;
    }

    public function getPrix(): ?int
    {
        return $this->Prix;
    }

    public function setPrix(int $Prix): self
    {
        $this->Prix = $Prix;

        return $this;
    }

    public function getHebergement(): ?int
    {
        return $this->Hebergement;
    }

    public function setHebergement(int $Hebergement): self
    {
        $this->Hebergement = $Hebergement;

        return $this;
    }

    public function getPensionComplete(): ?bool
    {
        return $this->Pension_Complete;
    }

    public function setPensionComplete(?bool $Pension_Complete): self
    {
        $this->Pension_Complete = $Pension_Complete;

        return $this;
    }

    public function getDemiPension(): ?bool
    {
        return $this->DemiPension;
    }

    public function setDemiPension(?bool $DemiPension): self
    {
        $this->DemiPension = $DemiPension;

        return $this;
    }

}
