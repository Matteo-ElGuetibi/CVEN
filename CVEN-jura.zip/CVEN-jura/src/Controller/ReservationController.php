<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Reservations;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;

class ReservationController extends AbstractController
{
    

    public function show(Request $request,EntityManagerInterface $manager, ManagerRegistry $doctrine){

        return $this->render('reservation/show.html.twig');

    }

    public function creer(Request $request,EntityManagerInterface $manager, ManagerRegistry $doctrine): Response
    {
        #$em = $this->$doctrine->getManager();
        $reservation = new Reservations();
        $form = $this->createFormBuilder($reservation)
            ->add('Hebergement')
            ->add('Nombre_Client')
            ->add('Menage')
            ->add('Restauration')
            ->add('Pension_Complete')
            ->add('DemiPension')
            ->add('Date_Arrivee')
            ->add('Date_Depart')
            ->add('save', SubmitType::class, [
                'label' => 'enregistrer'
            ])
            ->getForm();
        
        $form->handleRequest($request);
        
        if($form->isSubmitted() && $form->isValid()){

            if($reservation->getRestauration()==false){

                $reservation->setPensionComplete(false);
                $reservation->setDemiPension(false);
            }

            $reservation->setPrix(1200);

            $manager->persist($reservation);
            $manager->flush();
            $nb_reservation = $nb_reservation + 1;
            return $this->redirectToRoute('home', compact($nb_reservation));

        }

        #$reservation->setPrix(Prix: 1200)
        #    ->setNombreClient(Nombre_Client: 3)
        #    ->setMenage(Menage: false)
         #   ->setRestauration(Restauration: true)
           # ->setHebergement(Hebergement: 1);
       # $em->persist($reservation);
        #$em->flush();
        return $this->render('reservation/creer.html.twig', [
            'formReservation' => $form->createView()
        ]);
    }

}