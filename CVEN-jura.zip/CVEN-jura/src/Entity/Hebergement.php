<?php

namespace App\Entity;

use App\Repository\HebergementRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: HebergementRepository::class)]
class Hebergement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $Type_Hebergement;

    #[ORM\Column(type: 'string', length: 100)]
    private $Emplacement;

    #[ORM\Column(type: 'integer')]
    private $Etage;

    #[ORM\Column(type: 'string', length: 255)]
    private $Commentaire;

    #[ORM\Column(type: 'integer')]
    private $Chambres;

    #[ORM\Column(type: 'integer')]
    private $Prix = 500;

    #[ORM\Column(type: 'boolean')]
    private $Disponible = false;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTypeHebergement(): ?string
    {
        return $this->Type_Hebergement;
    }

    public function setTypeHebergement(string $Type_Hebergement): self
    {
        $this->Type_Hebergement = $Type_Hebergement;

        return $this;
    }

    public function getEmplacement(): ?string
    {
        return $this->Emplacement;
    }

    public function setEmplacement(string $Emplacement): self
    {
        $this->Emplacement = $Emplacement;

        return $this;
    }

    public function getEtage(): ?string
    {
        return $this->Etage;
    }

    public function setEtage(string $Etage): self
    {
        $this->Etage = $Etage;

        return $this;
    }

    public function getCommentaire(): ?string
    {
        return $this->Commentaire;
    }

    public function setCommentaire(string $Commentaire): self
    {
        $this->Commentaire = $Commentaire;

        return $this;
    }

    public function getChambres(): ?string
    {
        return $this->Chambres;
    }

    public function setChambres(string $Chambres): self
    {
        $this->Chambres = $Chambres;

        return $this;
    }

    public function getPrix(): ?int
    {
        return $this->Prix;
    }

    public function setPrix(int $Prix): self
    {
        $this->Prix = $Prix;

        return $this;
    }

    public function getDisponible(): ?bool
    {
        return $this->Disponible;
    }

    public function setDisponible(bool $Disponible): self
    {
        $this->Disponible = $Disponible;

        return $this;
    }
}
