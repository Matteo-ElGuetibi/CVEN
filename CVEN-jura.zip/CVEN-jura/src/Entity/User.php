<?php

namespace App\Entity;

use App\Repository\UserRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: UserRepository::class)]
class User
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100)]
    private $Login;

    #[ORM\Column(type: 'string', length: 50)]
    private $Password;

    #[ORM\Column(type: 'string', length: 50)]
    private $Nom;

    #[ORM\Column(type: 'string', length: 50)]
    private $Prenom;

    #[ORM\Column(type: 'boolean')]
    private $Administrateur;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLogin(): ?string
    {
        return $this->Login;
    }

    public function setLogin(string $Login): self
    {
        $this->Login = $Login;

        return $this;
    }

    public function getPassword(): ?string
    {
        return $this->Password;
    }

    public function setPassword(string $Password): self
    {
        $this->Password = $Password;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->Nom;
    }

    public function setNom(string $Nom): self
    {
        $this->Nom = $Nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->Prenom;
    }

    public function setPrenom(string $Prenom): self
    {
        $this->Prenom = $Prenom;

        return $this;
    }

    public function getAdministrateur(): ?bool
    {
        return $this->Administrateur;
    }

    public function setAdministrateur(bool $Administrateur): self
    {
        $this->Administrateur = $Administrateur;

        return $this;
    }
}
