<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use App\Controller\ReservationController;

class HomeController extends AbstractController
{

    
    public function index(): Response
    {
       

        if(isset($nb_reservation)){
            return $this->render('pages/home.html.twig', [
            'nombre' => $nb_reservation
        ]);
        }
        else{
            return $this->render('pages/home.html.twig');
        }

        
    }
}